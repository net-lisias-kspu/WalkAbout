﻿namespace KspWalkAbout.Entities
{
    internal class WorldCoordinates
    {
        public double Altitude { get; internal set; }
        public double Latitude { get; internal set; }
        public double Longitude { get; internal set; }
    }
}
