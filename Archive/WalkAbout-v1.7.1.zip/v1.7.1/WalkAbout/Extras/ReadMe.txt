﻿The .loc files in this folder can be used to add new places to place your kerbals. 

These locations are not adjacent to doors around the KSC, so they are not included in the core set of .loc files. However, they do represent locations that a user may find useful for gameplay.

Simply copy any (or all) of the .loc files into the locFiles folder and the new locations will be available for use.